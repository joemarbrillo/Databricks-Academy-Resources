-- Databricks notebook source
-- MAGIC %run ./Classroom-Setup-Common-SQL-WAREHOUSE

-- COMMAND ----------

-- Reset Volume to clean state (removes new batch files from previous demo runs)
BEGIN
  EXECUTE IMMEDIATE CONCAT('DROP VOLUME IF EXISTS ', my_catalog, '.data.course_data');
  EXECUTE IMMEDIATE CONCAT('CREATE VOLUME IF NOT EXISTS ', my_catalog, '.data.course_data');

  EXECUTE IMMEDIATE CONCAT(
    'INSERT OVERWRITE DIRECTORY ', CHAR(39), '/Volumes/', my_catalog, '/data/course_data/raw_products', CHAR(39),
    ' USING CSV OPTIONS (', CHAR(39), 'header', CHAR(39), ' ', CHAR(39), 'true', CHAR(39), ')',
    ' SELECT * FROM ', my_catalog, '.data.raw_products'
  );
  EXECUTE IMMEDIATE CONCAT(
    'INSERT OVERWRITE DIRECTORY ', CHAR(39), '/Volumes/', my_catalog, '/data/course_data/raw_orders', CHAR(39),
    ' USING CSV OPTIONS (', CHAR(39), 'header', CHAR(39), ' ', CHAR(39), 'true', CHAR(39), ')',
    ' SELECT * FROM ', my_catalog, '.data.raw_orders'
  );
  -- Seed the CDC source folder read by the SDP pipeline's silver_customers_cdc.sql.
  -- The pipeline scans the parent raw_customers_cdc/ dir; initial/ must exist on the
  -- first run or read_files fails with CF_EMPTY_DIR_FOR_SCHEMA_INFERENCE.
  -- (The new_batch/ subfolder is added later by the demo's F2 incremental step.)
  EXECUTE IMMEDIATE CONCAT(
    'INSERT OVERWRITE DIRECTORY ', CHAR(39), '/Volumes/', my_catalog, '/data/course_data/raw_customers_cdc/initial', CHAR(39),
    ' USING CSV OPTIONS (', CHAR(39), 'header', CHAR(39), ' ', CHAR(39), 'true', CHAR(39), ')',
    ' SELECT * FROM ', my_catalog, '.data.raw_customers_cdc'
  );
END;

-- COMMAND ----------

SELECT
  'Setup Complete' AS Status,
  my_catalog AS Catalog,
  'bronze, silver, gold' AS `Schemas`;


