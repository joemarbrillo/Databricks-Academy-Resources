# Databricks notebook source
# MAGIC %md
# MAGIC ![DB Academy](./Includes/images/db-academy.png)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <div style="max-width: 1000px; margin: 0 auto; font-family: sans-serif;">
# MAGIC <div style="background: #02A36F; color: white; border-radius: 8px; padding: 28px 32px; text-align: center; position: relative;">
# MAGIC   <div style="font-size: 14pt; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; opacity: 0.85; margin-bottom: 8px;">Lab</div>
# MAGIC   <div style="font-size: 24pt; font-weight: 700; line-height: 1.3;">Create a Metric View for Store Performance</div>
# MAGIC   <div style="font-size: 14pt; margin-top: 12px; opacity: 0.9;">Build a second metric view by assembling YAML blocks in the Catalog Explorer UI, then query it.</div>
# MAGIC </div>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## REQUIRED: SELECT A COMPUTE ENVIRONMENT
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Select Serverless Compute</strong>
# MAGIC   <div style="color:#333;">
# MAGIC
# MAGIC This notebook runs on Serverless compute. Before running any cells, confirm Serverless is selected in the compute dropdown at the top-right of this notebook. This course was developed and tested on <strong>Serverless environment version 5</strong>.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Setup
# MAGIC Run the cell below to configure your environment for this lesson. The setup script will initialize your catalog and schema so your queries run against the correct context.
# MAGIC

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-11

# COMMAND ----------

# MAGIC %md
# MAGIC **Context.** In Lesson 10 you read a metric view that the course created for you (`vw_product_metrics`). In this lab you'll create your own, **`vw_store_metrics`**, focused on store-level revenue. It has the same shape as `vw_product_metrics` but joins `dim_store` instead of `dim_product`.
# MAGIC
# MAGIC You'll create it the modern way: describe what you want to **Genie Code** and let it generate the metric-view definition. A manual block-by-block reference is provided too, in case you want to see the YAML or Genie isn't available.
# MAGIC
# MAGIC The lab has four steps: create the metric view (with Genie Code), confirm it exists, and run two queries against it.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Create the metric view with Genie Code
# MAGIC
# MAGIC You'll create `vw_store_metrics` by describing it to **Genie Code** and running the SQL it generates. Open Genie Code (Cmd/Ctrl + I) in the cell below, or use the full Genie / Assistant panel, and give it this prompt:
# MAGIC
# MAGIC > Create a Unity Catalog metric view named vw_store_metrics in the vintage_audio schema, using CREATE VIEW with METRICS LANGUAGE YAML. The source is the fact_orders table. Join dim_store on store_key. Add dimensions region and state from dim_store. Add measures total_revenue as SUM of total_amount and order_count as COUNT of order_id.
# MAGIC
# MAGIC Run what Genie generates. If it succeeds, skip to Step 2. Compare against the reference below, or use it if you'd rather not use Genie.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Use Genie Code (Cmd/Ctrl + I) with the prompt above to generate the CREATE VIEW statement, then run it.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary><strong>Here is the full CREATE statement</strong></summary>
# MAGIC <div style="position:relative; margin-top:8px;">
# MAGIC <button onclick="var t=document.getElementById('cbMetrics').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:6px 12px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#F9F7F4; border-radius:6px; padding:14px; margin:0; font-size:14px; overflow:auto;"><code id="cbMetrics">CREATE OR REPLACE VIEW vw&#95;store&#95;metrics
# MAGIC WITH METRICS LANGUAGE YAML AS $$
# MAGIC version: 1.1
# MAGIC source: fact&#95;orders
# MAGIC joins:
# MAGIC   - name: dim&#95;store
# MAGIC     source: dim&#95;store
# MAGIC     "on": dim&#95;store.store&#95;key = source.store&#95;key
# MAGIC dimensions:
# MAGIC   - name: region
# MAGIC     expr: dim&#95;store.region
# MAGIC     display&#95;name: Region
# MAGIC   - name: state
# MAGIC     expr: dim&#95;store.state
# MAGIC     display&#95;name: State
# MAGIC measures:
# MAGIC   - name: total&#95;revenue
# MAGIC     expr: SUM(source.total&#95;amount)
# MAGIC     display&#95;name: Total Revenue
# MAGIC   - name: order&#95;count
# MAGIC     expr: COUNT(source.order&#95;id)
# MAGIC     display&#95;name: Order Count
# MAGIC $$;</code></pre>
# MAGIC </div>
# MAGIC </details>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC **Prefer to build it in the UI instead?** You can also create the metric view in Catalog Explorer by assembling the YAML by hand. Expand the steps below.
# MAGIC
# MAGIC <details>
# MAGIC <summary>Manual UI alternative (Catalog Explorer)</summary>
# MAGIC <div style="margin-top:8px;">
# MAGIC <ol>
# MAGIC <li>In the sidebar, open <strong>Catalog</strong> &rarr; your <code>learn_get_started_dw_...</code> catalog &rarr; <code>vintage_audio</code> &rarr; <code>fact_orders</code>.</li>
# MAGIC <li>Click <strong>Create &gt; Metric view</strong>. Set the catalog to your <code>learn_get_started_dw_...</code> catalog, schema to <code>vintage_audio</code>, name to <code>vw_store_metrics</code>, and click <strong>Create</strong>.</li>
# MAGIC <li>Click the <strong>YAML</strong> toggle, delete any auto-generated sample content, and paste the YAML body from the reference above (everything between <code>$$</code> markers: the <code>version</code> through the <code>measures</code> block).</li>
# MAGIC <li>Click <strong>Save</strong>. If the UI reports a syntax error, check indentation: each <code>- name:</code> aligns within its block, and fields beneath are indented two more spaces.</li>
# MAGIC </ol>
# MAGIC </div>
# MAGIC </details>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Confirm the metric view exists
# MAGIC
# MAGIC Run the cell below to confirm your metric view was created in the correct schema.
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW VIEWS LIKE 'vw_store_metrics';

# COMMAND ----------

# MAGIC %md
# MAGIC You should see one row listing `vw_store_metrics`. If the result is empty, return to the Catalog Explorer tab and confirm the metric view was saved in the `vintage_audio` schema of your `learn_get_started_dw_...` catalog.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Query the metric view
# MAGIC
# MAGIC Now query your new metric view using the same three rules from Lesson 10: no `SELECT *`, wrap measures in `MEASURE()`, use `GROUP BY ALL`.
# MAGIC
# MAGIC #### Query 1: Revenue and order count by region
# MAGIC
# MAGIC Run the cell below. This query asks for total revenue and order count, grouped by region.
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   region,
# MAGIC   MEASURE(total_revenue) AS revenue,
# MAGIC   MEASURE(order_count)   AS orders
# MAGIC FROM vw_store_metrics
# MAGIC GROUP BY ALL
# MAGIC ORDER BY revenue DESC;

# COMMAND ----------

# MAGIC %md
# MAGIC You should see four rows, one per region (`West`, `Midwest`, `Southeast`, `Northeast`). The **West** region typically leads on revenue since it has the most stores (10), followed by Midwest and Southeast (7 each), then Northeast (6).
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Query 2: Top 10 states by revenue
# MAGIC
# MAGIC Run the cell below. This query asks for the top 10 states by revenue.
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   state,
# MAGIC   MEASURE(total_revenue) AS revenue,
# MAGIC   MEASURE(order_count)   AS orders
# MAGIC FROM vw_store_metrics
# MAGIC GROUP BY ALL
# MAGIC ORDER BY revenue DESC
# MAGIC LIMIT 10;

# COMMAND ----------

# MAGIC %md
# MAGIC You should see 10 rows. Each row is one US state with the total revenue from all stores in that state and the number of orders.
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Nice work
# MAGIC <div style="border-left: 4px solid #4caf50; background: #e8f5e9; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="color:#333;">
# MAGIC In this lab you:
# MAGIC
# MAGIC - Created a new metric view (<code>vw_store_metrics</code>) using <strong>Genie Code</strong> to generate the definition.
# MAGIC - Confirmed it was registered correctly with <code>SHOW VIEWS</code>.
# MAGIC - Queried it with the <code>MEASURE()</code> function and <code>GROUP BY ALL</code> pattern.
# MAGIC
# MAGIC Your schema now has two metric views. <code>vw_product_metrics</code> from Lesson 10 covers product-level metrics (category, brand). <code>vw_store_metrics</code> covers store-level metrics (region, state). Both metric views query the same <code>fact_orders</code> table but expose different angles on it. Different stakeholders can query the one that fits their question, with the same trustworthy measure definitions underneath.
# MAGIC
# MAGIC This is the final hands-on lesson of the course. The closing <strong>Summary and Next Steps</strong> notebook recaps what you built and points you toward where to go next.
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
# MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>