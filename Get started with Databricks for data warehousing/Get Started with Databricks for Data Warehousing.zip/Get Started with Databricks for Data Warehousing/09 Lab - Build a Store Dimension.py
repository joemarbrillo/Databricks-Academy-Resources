# Databricks notebook source
# MAGIC %md
# MAGIC ![DB Academy](./Includes/images/db-academy.png)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <div style="max-width: 1000px; margin: 0 auto; font-family: sans-serif;">
# MAGIC <div style="background: #02A36F; color: white; border-radius: 8px; padding: 28px 32px; text-align: center; position: relative;">
# MAGIC   <div style="font-size: 14pt; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; opacity: 0.85; margin-bottom: 8px;">Lab</div>
# MAGIC   <div style="font-size: 24pt; font-weight: 700; line-height: 1.3;">Build a Store Dimension</div>
# MAGIC   <div style="font-size: 14pt; margin-top: 12px; opacity: 0.9;">Extend the dimensional model with a calculated column and run regional analytics.</div>
# MAGIC </div>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## REQUIRED: SELECT A COMPUTE ENVIRONMENT
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Select Serverless Compute</strong>
# MAGIC   <div style="color:#333;">
# MAGIC
# MAGIC This notebook runs on Serverless compute. Before running any cells, confirm Serverless is selected in the compute dropdown at the top-right of this notebook. This course was developed and tested on <strong>Serverless environment version 5</strong>.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Setup
# MAGIC Run the cell below to configure your environment for this lesson. The setup script will initialize your catalog and schema so your queries run against the correct context.
# MAGIC

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-09

# COMMAND ----------

# MAGIC %md
# MAGIC **Context.** In Lesson 08 you built the full star schema and ended by running an analytical query in the SQL Editor. In this lab you'll extend the model and answer richer questions using **Genie Code** to write most of the SQL, and the **SQL Editor** for one task.
# MAGIC
# MAGIC The lab has **five tasks** that extend the star schema and analyze it from several angles.
# MAGIC
# MAGIC **How to work each task:** the default path is **Genie Code** : open it inline with **Cmd/Ctrl + I** in the target cell (or the full **Genie / Assistant** panel), give it the prompt provided, run the result, and expand the reference to compare. You can always write the SQL yourself.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Task 1: Confirm the starting state
# MAGIC
# MAGIC Confirm that `dim_store` exists with 30 rows from Lesson 08.
# MAGIC
# MAGIC **Genie Code prompt:**
# MAGIC
# MAGIC <div style="position:relative; margin:6px 0;">
# MAGIC <button onclick="var t=document.getElementById('gp_109_1').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:5px 11px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#EEF3F5; border-left:3px solid #1B5162; border-radius:6px; padding:12px 14px; margin:0; font-size:14px; white-space:pre-wrap;"><code id="gp_109_1">Count the rows in the dim_store table.</code></pre>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Use Genie Code with the prompt above, then run it.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary><strong>Here is the count query</strong></summary>
# MAGIC <div style="position:relative; margin-top:8px;">
# MAGIC <button onclick="var t=document.getElementById('cb_t1').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:6px 12px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#F9F7F4; border-radius:6px; padding:14px; margin:0; font-size:14px; overflow:auto;"><code id="cb_t1">SELECT COUNT(*) AS row_count FROM dim_store;</code></pre>
# MAGIC </div>
# MAGIC </details>

# COMMAND ----------

# MAGIC %md
# MAGIC You should see `30`. If you see `0` or a "table not found" error, the setup backfill rebuilds the model automatically, re-run the setup cell at the top and try again.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Task 2: Regional revenue
# MAGIC
# MAGIC Find **total revenue by region for 2024**, highest first. This joins `fact_orders` to `dim_store` (for `region`) and `dim_date` (to filter the year).
# MAGIC
# MAGIC **Genie Code prompt:**
# MAGIC
# MAGIC <div style="position:relative; margin:6px 0;">
# MAGIC <button onclick="var t=document.getElementById('gp_109_2').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:5px 11px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#EEF3F5; border-left:3px solid #1B5162; border-radius:6px; padding:12px 14px; margin:0; font-size:14px; white-space:pre-wrap;"><code id="gp_109_2" style="white-space:pre-wrap; overflow-wrap:break-word;">Using fact_orders joined to dim_store and dim_date on their surrogate keys, show each store region and its total revenue (sum of total_amount, rounded to 2 decimals) for the year 2024. Group by region and sort highest revenue first.</code></pre>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Use Genie Code with the prompt above, then run it.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary><strong>Here is the regional revenue query</strong></summary>
# MAGIC <div style="position:relative; margin-top:8px;">
# MAGIC <button onclick="var t=document.getElementById('cb_t2').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:6px 12px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#F9F7F4; border-radius:6px; padding:14px; margin:0; font-size:14px; overflow:auto;"><code id="cb_t2">SELECT
# MAGIC   ds.region,
# MAGIC   ROUND(SUM(fo.total_amount), 2) AS revenue
# MAGIC FROM fact_orders fo
# MAGIC JOIN dim_store ds ON fo.store_key = ds.store_key
# MAGIC JOIN dim_date  dd ON fo.date_key  = dd.date_key
# MAGIC WHERE dd.year = 2024
# MAGIC GROUP BY ds.region
# MAGIC ORDER BY revenue DESC;</code></pre>
# MAGIC </div>
# MAGIC </details>

# COMMAND ----------

# MAGIC %md
# MAGIC You should see four rows, one per region (`West`, `Midwest`, `Southeast`, `Northeast`). **West** tends to lead since it has the most stores (10), followed by Midwest and Southeast (7 each), then Northeast (6). Revenue scales roughly with store count.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Task 3: Add a calculated `price_tier` column to `dim_product`
# MAGIC
# MAGIC Classify each product by `list_price`:
# MAGIC
# MAGIC - `Budget`: under $1,000
# MAGIC - `Mid-range`: $1,000 to $3,000 (inclusive)
# MAGIC - `Premium`: over $3,000
# MAGIC
# MAGIC First add the column, then populate it with a `CASE` expression.
# MAGIC
# MAGIC **Genie Code prompt:**
# MAGIC
# MAGIC <div style="position:relative; margin:6px 0;">
# MAGIC <button onclick="var t=document.getElementById('gp_109_3').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:5px 11px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#EEF3F5; border-left:3px solid #1B5162; border-radius:6px; padding:12px 14px; margin:0; font-size:14px; white-space:pre-wrap;" ><code id="gp_109_3" style="white-space:pre-wrap; overflow-wrap:break-word;">On the dim_product table, add a STRING column called price_tier, then update it so list_price under 1000 is &#x27;Budget&#x27;, 1000 to 3000 inclusive is &#x27;Mid-range&#x27;, and over 3000 is &#x27;Premium&#x27;.</code></pre>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Use Genie Code with the prompt above. It should produce two statements:
# MAGIC -- an ALTER TABLE ... ADD COLUMNS, then an UPDATE ... SET price_tier = CASE ...
# MAGIC -- Run them, then continue to the verification below.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary><strong>Here are the full statements</strong></summary>
# MAGIC <div style="position:relative; margin-top:8px;">
# MAGIC <button onclick="var t=document.getElementById('cb_t3').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:6px 12px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#F9F7F4; border-radius:6px; padding:14px; margin:0; font-size:14px; overflow:auto;"><code id="cb_t3">ALTER TABLE dim_product ADD COLUMNS (price_tier STRING);
# MAGIC UPDATE dim_product
# MAGIC SET price_tier = CASE
# MAGIC   WHEN list_price &lt; 1000 THEN 'Budget'
# MAGIC   WHEN list_price &lt;= 3000 THEN 'Mid-range'
# MAGIC   ELSE 'Premium'
# MAGIC END;</code></pre>
# MAGIC </div>
# MAGIC </details>

# COMMAND ----------

# MAGIC %md
# MAGIC Now verify the split. Run the count below.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT price_tier, COUNT(*) AS product_count
# MAGIC FROM dim_product
# MAGIC GROUP BY price_tier
# MAGIC ORDER BY product_count DESC;

# COMMAND ----------

# MAGIC %md
# MAGIC You should see three rows. For the Vintage Audio catalog the split is **Budget = 125**, **Mid-range = 69**, **Premium = 56**. Budget is the largest tier (lots of lower-priced accessories), and the two higher tiers are smaller.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 4: Run a query in the SQL Editor
# MAGIC
# MAGIC Not every query belongs in a notebook. This task uses the **SQL Editor**, the same place you'll run ad-hoc analysis day to day.
# MAGIC
# MAGIC **Do this:**
# MAGIC
# MAGIC 1. Copy the query below with the **Copy** button.
# MAGIC 2. In the left sidebar, open **SQL Editor** (under *SQL*).
# MAGIC 3. Make sure the editor's catalog is your `learn_get_started_dw_...` catalog and the schema is `vintage_audio` (set them in the schema browser or with a `USE` statement).
# MAGIC 4. Paste the query, run it, and read the result right there in the editor.
# MAGIC
# MAGIC The query answers: **revenue by price tier for 2024.**

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary><strong>Here is the query to paste into the SQL Editor</strong></summary>
# MAGIC <div style="position:relative; margin-top:8px;">
# MAGIC <button onclick="var t=document.getElementById('cb_t4').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:6px 12px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#F9F7F4; border-radius:6px; padding:14px; margin:0; font-size:14px; overflow:auto;"><code id="cb_t4">SELECT
# MAGIC   dp.price_tier,
# MAGIC   COUNT(*)                       AS order_count,
# MAGIC   ROUND(SUM(fo.total_amount), 2) AS revenue
# MAGIC FROM fact_orders fo
# MAGIC JOIN dim_product dp ON fo.product_key = dp.product_key
# MAGIC JOIN dim_date    dd ON fo.date_key    = dd.date_key
# MAGIC WHERE dd.year = 2024
# MAGIC GROUP BY dp.price_tier
# MAGIC ORDER BY revenue DESC;</code></pre>
# MAGIC </div>
# MAGIC </details>

# COMMAND ----------

# MAGIC %md
# MAGIC You should see three rows. `Budget` typically wins on **order count** (many inexpensive accessories), while the higher tiers contribute more **revenue per order**. The exact ordering reflects the Vintage Audio product mix.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Task 5: Combine three dimensions
# MAGIC
# MAGIC Now the kind of cross-tabulation a star schema makes easy: **2024 revenue by region and price tier**, sorted by region then revenue descending within each region. This touches the fact table plus three dimensions (store, product, date).
# MAGIC
# MAGIC **Genie Code prompt:**
# MAGIC
# MAGIC <div style="position:relative; margin:6px 0;">
# MAGIC <button onclick="var t=document.getElementById('gp_109_4').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:5px 11px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#EEF3F5; border-left:3px solid #1B5162; border-radius:6px; padding:12px 14px; margin:0; font-size:14px; white-space:pre-wrap;"><code id="gp_109_4" style="white-space:pre-wrap; overflow-wrap:break-word;">Using fact_orders joined to dim_store, dim_product, and dim_date, show store region, product price_tier, and total revenue (sum of total_amount rounded to 2 decimals) for 2024. Group by region and price_tier, and order by region then revenue descending.</code></pre>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Use Genie Code with the prompt above, then run it.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary><strong>Here is the region-by-tier query</strong></summary>
# MAGIC <div style="position:relative; margin-top:8px;">
# MAGIC <button onclick="var t=document.getElementById('cb_t5').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:6px 12px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#F9F7F4; border-radius:6px; padding:14px; margin:0; font-size:14px; overflow:auto;"><code id="cb_t5">SELECT
# MAGIC   ds.region,
# MAGIC   dp.price_tier,
# MAGIC   ROUND(SUM(fo.total_amount), 2) AS revenue
# MAGIC FROM fact_orders fo
# MAGIC JOIN dim_store   ds ON fo.store_key   = ds.store_key
# MAGIC JOIN dim_product dp ON fo.product_key = dp.product_key
# MAGIC JOIN dim_date    dd ON fo.date_key    = dd.date_key
# MAGIC WHERE dd.year = 2024
# MAGIC GROUP BY ds.region, dp.price_tier
# MAGIC ORDER BY ds.region, revenue DESC;</code></pre>
# MAGIC </div>
# MAGIC </details>

# COMMAND ----------

# MAGIC %md
# MAGIC You should see 12 rows: 4 regions times 3 price tiers. Same shape as the simpler queries - joins on surrogate keys, filter on a dimension attribute, aggregate a fact measure. Adding a third dimension only extended the `SELECT` and `GROUP BY`.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Nice work
# MAGIC <div style="border-left: 4px solid #4caf50; background: #e8f5e9; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="color:#333;">
# MAGIC In this lab you:
# MAGIC
# MAGIC - Confirmed the dimensional model from Lesson 08.
# MAGIC - Used <strong>Genie Code</strong> to write regional, tier, and multi-dimension revenue queries.
# MAGIC - Added a calculated <code>price_tier</code> column to <code>dim_product</code>.
# MAGIC - Ran a query in the <strong>SQL Editor</strong>, the day-to-day analysis surface.
# MAGIC
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
# MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>