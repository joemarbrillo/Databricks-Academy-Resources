# Databricks notebook source
# MAGIC %md
# MAGIC ![DB Academy](./Includes/images/db-academy.png)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <div style="max-width: 1000px; margin: 0 auto; font-family: sans-serif;">
# MAGIC <div style="background: #1B5162; color: white; border-radius: 8px; padding: 28px 32px; text-align: center; position: relative;">
# MAGIC   <div style="font-size: 14pt; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; opacity: 0.85; margin-bottom: 8px;">Lesson 04</div>
# MAGIC   <div style="font-size: 24pt; font-weight: 700; line-height: 1.3;">Tuning Unity Catalog managed Tables for Analytical Queries</div>
# MAGIC   <div style="font-size: 14pt; margin-top: 12px; opacity: 0.9;">See how Predictive Optimization and automatic liquid clustering keep UC managed tables fast for analytical reads, mostly without manual work.</div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## REQUIRED: SELECT A COMPUTE ENVIRONMENT
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Select Serverless Compute</strong>
# MAGIC   <div style="color:#333;">
# MAGIC
# MAGIC This notebook runs on Serverless compute. Before running any cells, confirm Serverless is selected in the compute dropdown at the top-right of this notebook. This course was developed and tested on <strong>Serverless environment version 5</strong>.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Setup
# MAGIC Run the cell below to configure your environment for this lesson. The setup script will initialize your catalog and schema so your queries run against the correct context.

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-04

# COMMAND ----------

# MAGIC %md
# MAGIC ## What this lesson covers
# MAGIC
# MAGIC Every table in this course is a **UC managed table**, the storage layer that powers analytical workloads on Databricks. A few things govern how fast analytical scans run: how data files are laid out, how rows are clustered, and whether the query planner has good statistics.
# MAGIC
# MAGIC The big shift in recent years is that **most of this tuning now happens automatically.** **Predictive Optimization** watches how your tables are written and queried and runs the right maintenance for you, on serverless compute, in the background. You no longer schedule these operations by hand for most tables.
# MAGIC
# MAGIC In this lesson you will:
# MAGIC
# MAGIC 1. Inspect a table's physical layout with `DESCRIBE EXTENDED`.
# MAGIC 2. See what **Predictive Optimization** does for you and confirm it's enabled.
# MAGIC 3. Use **automatic liquid clustering** (`CLUSTER BY AUTO`), the modern replacement for partitioning and Z-ordering.
# MAGIC 4. Look at the manual commands (`OPTIMIZE`, `ANALYZE`, `VACUUM`) that Predictive Optimization runs automatically, and learn when you'd still reach for them yourself.
# MAGIC 5. Make a couple of changes to a table and read its version history.
# MAGIC 6. Explore lineage and history in Catalog Explorer.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 1. Where the table lives
# MAGIC
# MAGIC `DESCRIBE EXTENDED` returns columns, data types, storage location, and provider. You ran this in Lesson 02. The output has three sections separated by blank rows:
# MAGIC
# MAGIC <div style="max-width: 880px; margin: 20px auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <div style="display: flex; gap: 14px; align-items: stretch;">
# MAGIC     <!-- Part 1: Columns -->
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 10px 14px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 26px; height: 26px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px;">1</span>
# MAGIC         Column Schema
# MAGIC       </div>
# MAGIC       <div style="padding: 14px; background: #f8fafc; flex: 1;">
# MAGIC         <div style="font-size: 15px; color: #3d5a65; margin-bottom: 10px;"><strong>Names + data types</strong></div>
# MAGIC         <div style="background: #fff; border: 1px solid #DCE0E2; border-radius: 6px; padding: 10px; font-family: monospace; font-size: 14px; line-height: 1.7; color: #1B3139;">
# MAGIC           customer_id&nbsp;&nbsp;&nbsp;&nbsp;string<br/>
# MAGIC           customer_name&nbsp;&nbsp;string<br/>
# MAGIC           city&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;string<br/>
# MAGIC           postal_code&nbsp;&nbsp;&nbsp;&nbsp;int<br/>
# MAGIC           <span style="color: #5E7077;">... 6 more columns</span>
# MAGIC         </div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <!-- Part 2: Delta Statistics -->
# MAGIC     <div style="flex: 1; border: 2px solid #FF8C42; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #FF8C42; color: #fff; padding: 10px 14px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 26px; height: 26px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px;">2</span>
# MAGIC         Delta Statistics
# MAGIC       </div>
# MAGIC       <div style="padding: 14px; background: #FFFAF6; flex: 1;">
# MAGIC         <div style="font-size: 15px; color: #3d5a65; margin-bottom: 10px;"><strong>Min/max stats for file skipping</strong></div>
# MAGIC         <div style="display: flex; flex-direction: column; gap: 6px;">
# MAGIC           <div style="background: #fff; border: 1px solid #E8D5C4; border-radius: 6px; padding: 8px 10px; font-size: 15px; display: flex; justify-content: space-between;">
# MAGIC             <span style="color: #5E7077;">Method</span><span style="font-weight: 700; color: #1B3139; font-family: monospace; font-size: 14px;">first-32</span>
# MAGIC           </div>
# MAGIC           <div style="background: #fff; border: 1px solid #E8D5C4; border-radius: 6px; padding: 8px 10px; font-size: 14px; color: #3d5a65; line-height: 1.5;">
# MAGIC             <strong>Tracked columns</strong><br/>
# MAGIC             <span style="font-family: monospace;">customer_id, customer_name, email, city, state, postal_code, ...</span>
# MAGIC           </div>
# MAGIC         </div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <!-- Part 3: Table Info -->
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 10px 14px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 26px; height: 26px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px;">3</span>
# MAGIC         Table Metadata
# MAGIC       </div>
# MAGIC       <div style="padding: 14px; background: #f8fafc; flex: 1;">
# MAGIC         <div style="font-size: 15px; color: #3d5a65; margin-bottom: 10px;"><strong>Location, format, size</strong></div>
# MAGIC         <div style="display: flex; flex-direction: column; gap: 6px;">
# MAGIC           <div style="background: #fff; border: 1px solid #DCE0E2; border-radius: 6px; padding: 8px 10px; font-size: 15px; display: flex; justify-content: space-between;">
# MAGIC             <span style="color: #5E7077;">Provider</span><span style="font-weight: 700; color: #1B3139; font-family: monospace; font-size: 14px;">delta</span>
# MAGIC           </div>
# MAGIC           <div style="background: #fff; border: 1px solid #DCE0E2; border-radius: 6px; padding: 8px 10px; font-size: 15px; display: flex; justify-content: space-between;">
# MAGIC             <span style="color: #5E7077;">Type</span><span style="font-weight: 700; color: #1B3139; font-family: monospace; font-size: 14px;">MANAGED</span>
# MAGIC           </div>
# MAGIC           <div style="background: #fff; border: 1px solid #DCE0E2; border-radius: 6px; padding: 8px 10px; font-size: 15px; display: flex; justify-content: space-between;">
# MAGIC             <span style="color: #5E7077;">Location</span><span style="font-weight: 700; color: #1B3139; font-family: monospace; font-size: 14px;">s3://...</span>
# MAGIC           </div>
# MAGIC           <div style="background: #fff; border: 1px solid #DCE0E2; border-radius: 6px; padding: 8px 10px; font-size: 15px; display: flex; justify-content: space-between;">
# MAGIC             <span style="color: #5E7077;">Statistics</span><span style="font-weight: 700; color: #1B3139; font-family: monospace; font-size: 14px;">5,000 rows</span>
# MAGIC           </div>
# MAGIC         </div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE EXTENDED customers;

# COMMAND ----------

# MAGIC %md
# MAGIC In the **Detailed Table Information** section near the bottom, the `Location` row points at a path under your catalog's managed storage. That folder holds the underlying Parquet files plus a `_delta_log` directory that records every write.
# MAGIC
# MAGIC Because `customers` is a **Unity Catalog managed table**, it's exactly the kind of table Predictive Optimization looks after, which is what the next section is about.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 2. Predictive Optimization: tuning that runs itself
# MAGIC
# MAGIC **Predictive Optimization (PO)** is an AI-driven service that maintains your Unity Catalog managed tables for you. It continuously analyzes how each table is written and queried, then runs the right maintenance automatically on serverless compute, without you scheduling anything.
# MAGIC
# MAGIC <div style="width: 100%; margin: 16px 0;">
# MAGIC <svg viewBox="0 0 720 300" xmlns="http://www.w3.org/2000/svg" font-family="sans-serif" style="width: 100%; height: auto; display: block;">
# MAGIC   <text x="360" y="30" text-anchor="middle" fill="#1B5162" font-size="19" font-weight="700">WHAT PREDICTIVE OPTIMIZATION DOES FOR YOU</text>
# MAGIC   <rect x="270" y="120" width="180" height="70" rx="10" fill="#1B5162"/>
# MAGIC   <text x="360" y="150" text-anchor="middle" fill="#FFFFFF" font-size="16" font-weight="700">Predictive</text>
# MAGIC   <text x="360" y="172" text-anchor="middle" fill="#FFFFFF" font-size="16" font-weight="700">Optimization</text>
# MAGIC   <rect x="30" y="70" width="190" height="56" rx="8" fill="#F9F7F4" stroke="#00A972" stroke-width="1.6"/>
# MAGIC   <text x="125" y="93" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">Compact small files</text>
# MAGIC   <text x="125" y="113" text-anchor="middle" fill="#5E7077" font-size="15">runs OPTIMIZE for you</text>
# MAGIC   <rect x="30" y="135" width="190" height="56" rx="8" fill="#F9F7F4" stroke="#00A972" stroke-width="1.6"/>
# MAGIC   <text x="125" y="158" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">Cluster data layout</text>
# MAGIC   <text x="125" y="178" text-anchor="middle" fill="#5E7077" font-size="15">picks clustering keys</text>
# MAGIC   <rect x="500" y="70" width="190" height="56" rx="8" fill="#F9F7F4" stroke="#00A972" stroke-width="1.6"/>
# MAGIC   <text x="595" y="93" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">Collect statistics</text>
# MAGIC   <text x="595" y="113" text-anchor="middle" fill="#5E7077" font-size="15">on write, no ANALYZE</text>
# MAGIC   <rect x="500" y="135" width="190" height="56" rx="8" fill="#F9F7F4" stroke="#00A972" stroke-width="1.6"/>
# MAGIC   <text x="595" y="158" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">Vacuum old files</text>
# MAGIC   <text x="595" y="178" text-anchor="middle" fill="#5E7077" font-size="15">reclaims storage</text>
# MAGIC   <line x1="220" y1="98" x2="270" y2="145" stroke="#B5BFC4" stroke-width="1.6"/>
# MAGIC   <line x1="220" y1="163" x2="270" y2="158" stroke="#B5BFC4" stroke-width="1.6"/>
# MAGIC   <line x1="450" y1="145" x2="500" y2="98" stroke="#B5BFC4" stroke-width="1.6"/>
# MAGIC   <line x1="450" y1="158" x2="500" y2="163" stroke="#B5BFC4" stroke-width="1.6"/>
# MAGIC   <text x="360" y="240" text-anchor="middle" fill="#5E7077" font-size="15" font-style="italic">Runs automatically on serverless compute, based on how each table is used.</text>
# MAGIC   <text x="360" y="262" text-anchor="middle" fill="#5E7077" font-size="15" font-style="italic">No schedules to set up and no maintenance jobs to manage.</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC With PO enabled, Databricks automatically:
# MAGIC
# MAGIC - **Compacts small files** into larger ones (the work the `OPTIMIZE` command does), so scans open fewer files.
# MAGIC - **Clusters data layout** when automatic liquid clustering is on (next section), choosing and adapting the clustering keys from your query patterns.
# MAGIC - **Collects column statistics** as data is written, so the query planner makes better decisions, no separate `ANALYZE` pass needed.
# MAGIC - **Vacuums** unreferenced old files to reclaim storage.
# MAGIC
# MAGIC PO is **enabled by default** for new accounts and tables and has been rolling out across existing accounts, so on a current workspace it is typically already on. It's the recommended default for all Unity Catalog managed tables.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Confirm it's enabled
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 14px 18px; border-radius: 4px; margin: 12px 0; font-size: 15px; color: #333; line-height: 1.6;">
# MAGIC   <strong style="color: #1565c0; font-size: 16px;">Try this in Catalog Explorer</strong>
# MAGIC   <ol style="margin: 8px 0 0 0; padding-left: 20px;">
# MAGIC     <li>In the left sidebar, click <strong>Catalog</strong>.</li>
# MAGIC     <li>Navigate to your catalog &#x2192; <code style="font-size: 15px;">vintage_audio</code> schema &#x2192; <code style="font-size: 15px;">customers</code> table.</li>
# MAGIC     <li>Open the table's <strong>Details</strong> tab and look for the <strong>Predictive Optimization</strong> field. It shows whether PO is enabled and whether the setting is inherited from the catalog or schema.</li>
# MAGIC   </ol>
# MAGIC </div>
# MAGIC
# MAGIC If it shows as inherited and enabled, you don't need to do anything. PO is already maintaining this table. (Enabling or disabling PO is an account/catalog/schema-level admin action, so it's not something you toggle per notebook.)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 3. Automatic liquid clustering: the modern layout lever
# MAGIC
# MAGIC To make filtered scans fast, the rows you query together should sit in the same files, so the engine can **skip** files that can't match. Historically you controlled this with partitioning or `OPTIMIZE ZORDER BY`. Today the recommended approach is **liquid clustering**, and specifically **automatic liquid clustering**.
# MAGIC
# MAGIC <div style="width: 100%; margin: 16px 0;">
# MAGIC <svg viewBox="0 0 760 470" xmlns="http://www.w3.org/2000/svg" font-family="sans-serif" style="width: 100%; height: auto; display: block;">
# MAGIC   <text x="380" y="30" text-anchor="middle" fill="#1B5162" font-size="19" font-weight="700">HOW CLUSTERING MAKES SCANS FAST</text>
# MAGIC   <text x="380" y="54" text-anchor="middle" fill="#5E7077" font-size="15" font-family="monospace">SELECT * FROM customers WHERE state = 'CA';</text>
# MAGIC   <rect x="20" y="74" width="720" height="180" rx="10" fill="#F9F7F4" stroke="#1B5162" stroke-width="1.5"/>
# MAGIC   <text x="40" y="102" fill="#FE3722" font-size="15" font-weight="700">UNCLUSTERED &#8212; CA rows scattered, every file scanned</text>
# MAGIC   <rect x="40" y="118" width="160" height="64" rx="5" fill="#FFFFFF" stroke="#FE3722" stroke-width="1.5"/>
# MAGIC   <text x="120" y="142" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">file_001</text>
# MAGIC   <text x="120" y="162" text-anchor="middle" fill="#5E7077" font-size="14">AK, CA, FL, NY</text>
# MAGIC   <text x="120" y="178" text-anchor="middle" fill="#FE3722" font-size="14" font-weight="700">SCANNED</text>
# MAGIC   <rect x="212" y="118" width="160" height="64" rx="5" fill="#FFFFFF" stroke="#FE3722" stroke-width="1.5"/>
# MAGIC   <text x="292" y="142" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">file_002</text>
# MAGIC   <text x="292" y="162" text-anchor="middle" fill="#5E7077" font-size="14">AZ, CA, GA, OH</text>
# MAGIC   <text x="292" y="178" text-anchor="middle" fill="#FE3722" font-size="14" font-weight="700">SCANNED</text>
# MAGIC   <rect x="384" y="118" width="160" height="64" rx="5" fill="#FFFFFF" stroke="#FE3722" stroke-width="1.5"/>
# MAGIC   <text x="464" y="142" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">file_003</text>
# MAGIC   <text x="464" y="162" text-anchor="middle" fill="#5E7077" font-size="14">CA, IL, MA, TX</text>
# MAGIC   <text x="464" y="178" text-anchor="middle" fill="#FE3722" font-size="14" font-weight="700">SCANNED</text>
# MAGIC   <rect x="556" y="118" width="160" height="64" rx="5" fill="#FFFFFF" stroke="#FE3722" stroke-width="1.5"/>
# MAGIC   <text x="636" y="142" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">file_004</text>
# MAGIC   <text x="636" y="162" text-anchor="middle" fill="#5E7077" font-size="14">CA, NV, OR, WA</text>
# MAGIC   <text x="636" y="178" text-anchor="middle" fill="#FE3722" font-size="14" font-weight="700">SCANNED</text>
# MAGIC   <text x="40" y="222" fill="#0b2026" font-size="15" font-weight="700">All 4 files scanned.</text>
# MAGIC   <text x="40" y="242" fill="#5E7077" font-size="14">CA rows are mixed into every file, so the engine must read them all.</text>
# MAGIC   <rect x="20" y="270" width="720" height="184" rx="10" fill="#F9F7F4" stroke="#1B5162" stroke-width="1.5"/>
# MAGIC   <text x="40" y="298" fill="#00A972" font-size="15" font-weight="700">CLUSTERED BY state &#8212; CA rows together, other files skipped</text>
# MAGIC   <rect x="40" y="314" width="160" height="64" rx="5" fill="#FFFFFF" stroke="#00A972" stroke-width="1.5"/>
# MAGIC   <text x="120" y="338" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">file_001</text>
# MAGIC   <text x="120" y="358" text-anchor="middle" fill="#5E7077" font-size="14">CA, CA, CA, CA</text>
# MAGIC   <text x="120" y="374" text-anchor="middle" fill="#00A972" font-size="14" font-weight="700">SCANNED</text>
# MAGIC   <rect x="212" y="314" width="160" height="64" rx="5" fill="#FFFFFF" stroke="#B5BFC4" stroke-width="1.2" stroke-dasharray="4,3"/>
# MAGIC   <text x="292" y="338" text-anchor="middle" fill="#5E7077" font-size="15" font-weight="700">file_002</text>
# MAGIC   <text x="292" y="358" text-anchor="middle" fill="#B5BFC4" font-size="14">FL, GA, HI, IA</text>
# MAGIC   <text x="292" y="374" text-anchor="middle" fill="#5E7077" font-size="14" font-weight="700">SKIPPED</text>
# MAGIC   <rect x="384" y="314" width="160" height="64" rx="5" fill="#FFFFFF" stroke="#B5BFC4" stroke-width="1.2" stroke-dasharray="4,3"/>
# MAGIC   <text x="464" y="338" text-anchor="middle" fill="#5E7077" font-size="15" font-weight="700">file_003</text>
# MAGIC   <text x="464" y="358" text-anchor="middle" fill="#B5BFC4" font-size="14">IL, IN, KS, KY</text>
# MAGIC   <text x="464" y="374" text-anchor="middle" fill="#5E7077" font-size="14" font-weight="700">SKIPPED</text>
# MAGIC   <rect x="556" y="314" width="160" height="64" rx="5" fill="#FFFFFF" stroke="#B5BFC4" stroke-width="1.2" stroke-dasharray="4,3"/>
# MAGIC   <text x="636" y="338" text-anchor="middle" fill="#5E7077" font-size="15" font-weight="700">file_004</text>
# MAGIC   <text x="636" y="358" text-anchor="middle" fill="#B5BFC4" font-size="14">NY, OH, PA, TX</text>
# MAGIC   <text x="636" y="374" text-anchor="middle" fill="#5E7077" font-size="14" font-weight="700">SKIPPED</text>
# MAGIC   <text x="40" y="418" fill="#0b2026" font-size="15" font-weight="700">Only 1 of 4 files scanned.</text>
# MAGIC   <text x="40" y="438" fill="#5E7077" font-size="14">Rows are co-located by state, so file-skipping reads only what it must.</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC With **`CLUSTER BY AUTO`**, Predictive Optimization analyzes how the table is queried, **chooses the clustering keys for you**, and adapts them over time as usage changes. Liquid clustering replaces both partitioning and Z-ordering for the large majority of tables; it's flexible (you can change keys without rewriting the whole table) and it doesn't require you to guess the right columns up front.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Turn on automatic liquid clustering
# MAGIC
# MAGIC Enabling it is a single statement. Predictive Optimization then selects the clustering keys and clusters the data in the background, no key list required from you.
# MAGIC
# MAGIC <div style="width: 100%; margin: 16px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <div style="display: flex; gap: 14px; align-items: stretch;">
# MAGIC     <!-- Option 1: AUTO -->
# MAGIC     <div style="flex: 1; border: 2px solid #00A972; border-radius: 10px; overflow: hidden;">
# MAGIC       <div style="background: #00A972; color: #fff; padding: 10px 14px; text-align: center;">
# MAGIC         <div style="font-size: 15px; font-weight: 700; font-family: monospace;">CLUSTER BY AUTO</div>
# MAGIC         <div style="font-size: 14px; opacity: 0.85;">Recommended default</div>
# MAGIC       </div>
# MAGIC       <div style="padding: 14px; background: #F0FAF5; font-size: 15px; color: #3d5a65;">
# MAGIC         <div style="display: flex; flex-direction: column; gap: 6px;">
# MAGIC           <div style="display: flex; align-items: center; gap: 8px;"><span style="color: #00A972; font-weight: 700;">&#10003;</span> PO picks clustering keys from query patterns</div>
# MAGIC           <div style="display: flex; align-items: center; gap: 8px;"><span style="color: #00A972; font-weight: 700;">&#10003;</span> Adapts over time as usage changes</div>
# MAGIC           <div style="display: flex; align-items: center; gap: 8px;"><span style="color: #00A972; font-weight: 700;">&#10003;</span> Best when you're unsure which columns matter most</div>
# MAGIC         </div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <!-- Option 2: Manual keys -->
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 10px 14px; text-align: center;">
# MAGIC         <div style="font-size: 15px; font-weight: 700; font-family: monospace;">CLUSTER BY (col1, col2)</div>
# MAGIC         <div style="font-size: 14px; opacity: 0.85;">When you know the columns</div>
# MAGIC       </div>
# MAGIC       <div style="padding: 14px; background: #f8fafc; font-size: 15px; color: #3d5a65;">
# MAGIC         <div style="display: flex; flex-direction: column; gap: 6px;">
# MAGIC           <div style="display: flex; align-items: center; gap: 8px;"><span style="color: #1B5162; font-weight: 700;">&#10003;</span> You specify exact clustering keys</div>
# MAGIC           <div style="display: flex; align-items: center; gap: 8px;"><span style="color: #1B5162; font-weight: 700;">&#10003;</span> Keys stay fixed until you change them</div>
# MAGIC           <div style="display: flex; align-items: center; gap: 8px;"><span style="color: #1B5162; font-weight: 700;">&#10003;</span> Best when query patterns are well known</div>
# MAGIC         </div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC   <div style="font-size: 15px; color: #5E7077; margin-top: 10px; text-align: center;">Both replace partitioning and Z-ordering. No rewrite needed to change keys later.</div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE customers CLUSTER BY AUTO;

# COMMAND ----------

# MAGIC %md
# MAGIC That's the whole setup. From here, PO decides which columns to cluster on based on how `customers` is actually queried, and keeps the layout current as those patterns change.
# MAGIC
# MAGIC A few notes for real-world use:
# MAGIC
# MAGIC - **Manual keys are still available.** If you already know the right columns, you can pin them with `CLUSTER BY (col1, col2)` instead of `AUTO`. Automatic is the better default when you're unsure or the workload shifts over time.
# MAGIC - **Liquid clustering replaces partitioning and Z-ordering.** You don't combine them; a clustered table doesn't use `PARTITIONED BY` or `ZORDER BY`.
# MAGIC - **Z-order still exists** and isn't wrong, but it's no longer what Databricks steers you toward for new tables. Reach for liquid clustering first.
# MAGIC
# MAGIC > **A note on scale.** On this 5,000-row `customers` table you won't see a runtime difference: the data fits in a single file, so there's nothing to skip. On a production table with hundreds of millions of rows across many files, clustering routinely cuts scan time many times over. The technique scales; the demo dataset is just small.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 4. The manual commands underneath
# MAGIC
# MAGIC Predictive Optimization runs three operations for you. It's still worth seeing them directly once, both to understand what PO is doing and because you may need them when PO isn't available (for example, on tables that aren't UC managed, or when you want to force the work immediately).
# MAGIC
# MAGIC <div style="width: 100%; margin: 16px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <div style="display: flex; gap: 14px;">
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 10px 14px; font-size: 16px; font-weight: 700; text-align: center;">OPTIMIZE</div>
# MAGIC       <div style="padding: 14px; background: #f8fafc; font-size: 15px; color: #3d5a65; line-height: 1.5; text-align: center;">
# MAGIC         <div style="font-weight: 700; color: #1B3139; margin-bottom: 4px;">Compact files</div>
# MAGIC         <div>Merges small files into fewer large ones. Fewer files = faster scans.</div>
# MAGIC         <div style="margin-top: 8px; font-size: 14px; color: #00A972; font-weight: 600;">PO does this automatically</div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <div style="flex: 1; border: 2px solid #FF8C42; border-radius: 10px; overflow: hidden;">
# MAGIC       <div style="background: #FF8C42; color: #fff; padding: 10px 14px; font-size: 16px; font-weight: 700; text-align: center;">ANALYZE</div>
# MAGIC       <div style="padding: 14px; background: #FFFAF6; font-size: 15px; color: #3d5a65; line-height: 1.5; text-align: center;">
# MAGIC         <div style="font-weight: 700; color: #1B3139; margin-bottom: 4px;">Collect statistics</div>
# MAGIC         <div>Gives the query planner row counts, min/max, and distinct counts per column.</div>
# MAGIC         <div style="margin-top: 8px; font-size: 14px; color: #00A972; font-weight: 600;">PO does this on write</div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 10px 14px; font-size: 16px; font-weight: 700; text-align: center;">VACUUM</div>
# MAGIC       <div style="padding: 14px; background: #f8fafc; font-size: 15px; color: #3d5a65; line-height: 1.5; text-align: center;">
# MAGIC         <div style="font-weight: 700; color: #1B3139; margin-bottom: 4px;">Reclaim storage</div>
# MAGIC         <div>Deletes old files past the retention window (default 7 days).</div>
# MAGIC         <div style="margin-top: 8px; font-size: 14px; color: #00A972; font-weight: 600;">PO does this automatically</div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### OPTIMIZE - compact files now
# MAGIC
# MAGIC `OPTIMIZE` compacts small files into larger ones. This is the file-compaction work PO performs automatically; running it by hand simply does it on demand.

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE customers;

# COMMAND ----------

# MAGIC %md
# MAGIC The result reports the compaction metrics. On a small table the impact is modest; on a heavily-written production table it can cut scan time substantially. With PO enabled you normally never run this yourself.

# COMMAND ----------

# MAGIC %md
# MAGIC ### ANALYZE - statistics for the planner
# MAGIC
# MAGIC The query planner uses column statistics (row counts, min/max, distinct counts) to choose good plans, especially for joins. With Predictive Optimization, **statistics are collected automatically as data is written**, so you rarely run `ANALYZE` yourself. You can still trigger it explicitly:

# COMMAND ----------

# MAGIC %sql
# MAGIC ANALYZE TABLE customers COMPUTE STATISTICS FOR ALL COLUMNS;

# COMMAND ----------

# MAGIC %md
# MAGIC The value here is concrete: better statistics mean the planner stops guessing about how many rows a filter or join will produce, which leads to faster plans. Confirm the stats landed by describing a single column:

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE EXTENDED customers state;

# COMMAND ----------

# MAGIC %md
# MAGIC You should see `min`, `max`, `num_nulls`, `distinct_count`, and `avg_col_len` for the `state` column. Under PO, this kind of statistic is kept current for you in the background.

# COMMAND ----------

# MAGIC %md
# MAGIC ### VACUUM - reclaim storage from old files
# MAGIC
# MAGIC When a table is rewritten, the old files aren't deleted right away; they're retained (default 7 days) so time-travel queries against recent versions still work. `VACUUM` deletes files past that retention window. **Vacuuming is also part of Predictive Optimization**, which removes unreferenced files for you on managed tables. Preview what would be removed with `DRY RUN`:

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM customers DRY RUN;

# COMMAND ----------

# MAGIC %md
# MAGIC On this freshly-created table the list is empty (no files are old enough yet). With PO handling vacuum automatically, manual `VACUUM` is mainly for tables PO doesn't manage. Avoid `VACUUM ... RETAIN 0 HOURS`: it deletes files immediately and breaks time travel.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 5. Version history: actually change the table, then read it
# MAGIC
# MAGIC Every write to a UC managed table is recorded as a new **version** in its transaction log. To see versions that show real change, let's make two small edits: insert a row, then delete it. (We add a clearly fake customer so the table is left exactly as it started.)
# MAGIC
# MAGIC <div style="width: 100%; margin: 16px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <div style="font-size: 15px; font-weight: 700; color: #1B5162; margin-bottom: 8px;">What DESCRIBE HISTORY will show after these two edits:</div>
# MAGIC   <div style="display: flex; gap: 0; align-items: center;">
# MAGIC     <div style="flex: 1; background: #f8fafc; border: 2px solid #DCE0E2; border-radius: 10px; padding: 10px; text-align: center;">
# MAGIC       <div style="font-size: 14px; font-weight: 700; color: #5E7077;">Version 0</div>
# MAGIC       <div style="font-size: 14px; font-weight: 700; color: #1B3139; margin-top: 4px;">CREATE TABLE</div>
# MAGIC       <div style="font-size: 14px; color: #5E7077;">Setup script</div>
# MAGIC     </div>
# MAGIC     <div style="flex: 0 0 20px; text-align: center; font-size: 18px; color: #1B5162;">&#x2192;</div>
# MAGIC     <div style="flex: 1.2; background: #f8fafc; border: 2px solid #DCE0E2; border-radius: 10px; padding: 10px; text-align: center;">
# MAGIC       <div style="font-size: 14px; font-weight: 700; color: #5E7077;">Versions 1-3</div>
# MAGIC       <div style="font-size: 14px; font-weight: 700; color: #1B3139; margin-top: 4px;">CLUSTER BY AUTO</div>
# MAGIC       <div style="font-size: 14px; color: #5E7077;">Protocol upgrade + backfill + cluster</div>
# MAGIC     </div>
# MAGIC     <div style="flex: 0 0 20px; text-align: center; font-size: 18px; color: #1B5162;">&#x2192;</div>
# MAGIC     <div style="flex: 1; background: #EDF5F7; border: 2px solid #1B5162; border-radius: 10px; padding: 10px; text-align: center;">
# MAGIC       <div style="font-size: 14px; font-weight: 700; color: #1B5162;">Version 4</div>
# MAGIC       <div style="font-size: 14px; font-weight: 700; color: #1B3139; margin-top: 4px;">WRITE</div>
# MAGIC       <div style="font-size: 14px; color: #1B5162;">INSERT one row &#x2193;</div>
# MAGIC     </div>
# MAGIC     <div style="flex: 0 0 20px; text-align: center; font-size: 18px; color: #1B5162;">&#x2192;</div>
# MAGIC     <div style="flex: 1; background: #EDF5F7; border: 2px solid #1B5162; border-radius: 10px; padding: 10px; text-align: center;">
# MAGIC       <div style="font-size: 14px; font-weight: 700; color: #1B5162;">Version 5</div>
# MAGIC       <div style="font-size: 14px; font-weight: 700; color: #1B3139; margin-top: 4px;">DELETE</div>
# MAGIC       <div style="font-size: 14px; color: #1B5162;">Remove that row &#x2193;</div>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Version N+1: insert one row
# MAGIC INSERT INTO customers (customer_id, customer_name, email, state)
# MAGIC VALUES ('DEMO-0001', 'History Demo', 'demo@example.com', 'CA');

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Version N+2: delete the row we just added
# MAGIC DELETE FROM customers WHERE customer_id = 'DEMO-0001';

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY customers;

# COMMAND ----------

# MAGIC %md
# MAGIC Now the history is meaningful. You should see six versions (0 through 5):
# MAGIC
# MAGIC - **Version 0** -- `CREATE OR REPLACE TABLE AS SELECT`: the setup script created the table.
# MAGIC - **Versions 1-3** -- these three came from the single `CLUSTER BY AUTO` statement you ran in Section 3. Liquid clustering requires **row tracking** (stable IDs on every row so the engine can track which rows moved between files during re-clustering). Enabling it triggers three log entries: an **UPGRADE PROTOCOL** to a Delta version that supports row tracking, a **ROW TRACKING BACKFILL** that stamps existing rows with tracking IDs, and the **CLUSTER BY** metadata change itself.
# MAGIC - **Version 4** -- `WRITE`: the INSERT you just ran.
# MAGIC - **Version 5** -- `DELETE`: the DELETE that removed it.
# MAGIC
# MAGIC Each row shows the **version**, **timestamp**, **operation**, and the user who made the change. This is what makes a UC managed table auditable and recoverable: you can see exactly what each version did, and roll back with `RESTORE TABLE ... TO VERSION AS OF <n>` if needed.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 6. Explore lineage and history in Catalog Explorer
# MAGIC
# MAGIC Unity Catalog automatically tracks how each table was created and what reads from it. This is **lineage**, and it's one of the most useful features for keeping a warehouse maintainable.
# MAGIC
# MAGIC <div style="width: 100%; margin: 16px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <!-- Row 1: Lineage steps -->
# MAGIC   <div style="font-size: 16px; font-weight: 700; color: #1B5162; margin-bottom: 8px;">See the lineage graph</div>
# MAGIC   <div style="display: flex; gap: 0; align-items: stretch; margin-bottom: 16px;">
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 8px 12px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 6px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">1</span> Click Catalog
# MAGIC       </div>
# MAGIC       <div style="padding: 10px 12px; background: #f8fafc; flex: 1; font-size: 15px; color: #3d5a65; line-height: 1.5;">In the left sidebar</div>
# MAGIC     </div>
# MAGIC     <div style="flex: 0 0 30px; display: flex; align-items: center; justify-content: center; font-size: 22px; color: #1B5162;">&#x2192;</div>
# MAGIC     <div style="flex: 1.3; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 8px 12px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 6px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">2</span> Navigate to table
# MAGIC       </div>
# MAGIC       <div style="padding: 10px 12px; background: #f8fafc; flex: 1; font-size: 15px; color: #3d5a65;">Your catalog &#x2192; <strong>vintage_audio</strong> &#x2192; <strong>customers</strong></div>
# MAGIC     </div>
# MAGIC     <div style="flex: 0 0 30px; display: flex; align-items: center; justify-content: center; font-size: 22px; color: #1B5162;">&#x2192;</div>
# MAGIC     <div style="flex: 1.3; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 8px 12px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 6px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">3</span> Lineage tab
# MAGIC       </div>
# MAGIC       <div style="padding: 10px 12px; background: #f8fafc; flex: 1; font-size: 15px; color: #3d5a65;">Click <strong>See lineage graph</strong> to see the <code style="font-size: 14px;">data</code> volume flowing into <code style="font-size: 14px;">customers</code></div>
# MAGIC     </div>
# MAGIC     <div style="flex: 0 0 30px; display: flex; align-items: center; justify-content: center; font-size: 22px; color: #1B5162;">&#x2192;</div>
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 8px 12px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 6px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">4</span> Expand nodes
# MAGIC       </div>
# MAGIC       <div style="padding: 10px 12px; background: #f8fafc; flex: 1; font-size: 15px; color: #3d5a65;">Click <strong>+</strong> on any node to explore connections</div>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC   <!-- Row 2: History -->
# MAGIC   <div style="font-size: 16px; font-weight: 700; color: #1B5162; margin-bottom: 8px;">See the version history</div>
# MAGIC   <div style="border: 2px solid #00A972; border-radius: 10px; overflow: hidden;">
# MAGIC     <div style="background: #00A972; color: #fff; padding: 8px 14px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 6px;">
# MAGIC       <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">5</span> Click the History tab
# MAGIC     </div>
# MAGIC     <div style="padding: 12px 14px; background: #F0FAF5; font-size: 15px; color: #3d5a65; line-height: 1.5;">
# MAGIC       You will see the same versions from <code style="font-size: 14px;">DESCRIBE HISTORY</code> in a browsable UI: CREATE TABLE (v0), protocol upgrade + backfill + CLUSTER BY (v1-3), WRITE (v4), DELETE (v5). Each row shows the operation, timestamp, and user. You can compare versions and restore from here.
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## What you did in this lesson
# MAGIC
# MAGIC <div style="border-left: 4px solid #4caf50; background: #e8f5e9; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="color:#333;">
# MAGIC
# MAGIC The headline: on modern Databricks, **table tuning is largely automatic**. Predictive Optimization and automatic liquid clustering do the work the manual commands used to require.
# MAGIC
# MAGIC | Capability | What it does | Your involvement |
# MAGIC |---|---|---|
# MAGIC | **Predictive Optimization** | Runs compaction, clustering, statistics, and vacuum automatically on UC managed tables | Confirm it's enabled; otherwise nothing |
# MAGIC | **Automatic liquid clustering** (`CLUSTER BY AUTO`) | PO picks and adapts clustering keys from query patterns; replaces partitioning and Z-order | One-time `CLUSTER BY AUTO` |
# MAGIC | `OPTIMIZE` | Compacts small files | Manual only when PO isn't managing the table |
# MAGIC | `ANALYZE` | Collects column statistics | Usually automatic (stats on write) |
# MAGIC | `VACUUM` | Deletes old unreferenced files | Usually automatic under PO |
# MAGIC | `DESCRIBE HISTORY` / History tab | Shows every version and its metrics | Read it when investigating or restoring |
# MAGIC
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
# MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>