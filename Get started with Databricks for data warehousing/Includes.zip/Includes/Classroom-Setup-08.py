# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# M08 CREATES the star schema. Ensure its inputs exist: the source
# dimension tables and a fully loaded orders_bronze.
ensure_source_dimensions()
ensure_orders_bronze_full()
