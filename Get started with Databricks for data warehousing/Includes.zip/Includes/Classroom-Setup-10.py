# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# M10 READS a pre-created metric view. Ensure the star schema and the
# vw_product_metrics metric view the demo explores.
ensure_metric_view_product()
