# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# M02 queries the source tables. Ensure they exist with correct row counts.
ensure_source_dimensions()
