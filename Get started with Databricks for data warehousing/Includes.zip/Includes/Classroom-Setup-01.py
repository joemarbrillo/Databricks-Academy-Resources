# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# M01 is a workspace walkthrough (demo only). It needs the catalog, schema,
# and volume to be present, which Classroom-Setup-Common guarantees. No table
# backfill is required.
