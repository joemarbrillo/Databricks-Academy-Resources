# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# M11 (lab) CREATES its own metric view (vw_store_metrics). It only needs
# the star schema underneath.
ensure_star_schema()
