# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# M06 CREATES orders_bronze with Auto Loader. It needs only the staged
# CSV files, which Classroom-Setup-Common guarantees. No table backfill.
# (foundation only: CSVs are staged by Classroom-Setup-Common)
