# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# M09 (lab) uses and extends the star schema. Ensure the full star schema.
ensure_star_schema()
